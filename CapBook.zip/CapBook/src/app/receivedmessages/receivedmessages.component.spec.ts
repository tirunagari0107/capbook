import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceivedmessagesComponent } from './receivedmessages.component';

describe('ReceivedmessagesComponent', () => {
  let component: ReceivedmessagesComponent;
  let fixture: ComponentFixture<ReceivedmessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceivedmessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceivedmessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
