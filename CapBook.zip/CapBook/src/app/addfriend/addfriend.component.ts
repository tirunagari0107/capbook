import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Friendrequest } from '../friendrequest';

@Component({
  selector: 'app-addfriend',
  templateUrl: './addfriend.component.html',
  styleUrls: ['./addfriend.component.css']
})
export class AddfriendComponent implements OnInit {
  senderEmail:string
  senderEmailid:string
  receiverEmail:string
  receiverEmailid:string
  friendrequest:Friendrequest
  errorMessage:string
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.senderEmail=this.route.snapshot.paramMap.get('senderEmail');
    this.senderEmailid=this.senderEmail;
    this.receiverEmail=this.route.snapshot.paramMap.get('receiverEmail');
    this.receiverEmailid=this.receiverEmail;
    this.capbookservice.acceptRequest(this.senderEmailid,this.receiverEmailid).subscribe(
      friendrequest=>{
      this.friendrequest=friendrequest;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
  }
  public navigateBack(): void{
    this.router.navigate(['/profile'])
  }

}
