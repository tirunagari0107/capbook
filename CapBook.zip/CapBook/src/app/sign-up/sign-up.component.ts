import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor(private router:Router,private capbookService:CapbookserviceService
     ) { }

  message:string;
  errorMessage:string;
    signUp:SignUp
  ngOnInit() {
  }
  onSubmit(signUp:SignUp){
    this.capbookService.acceptUserDetails(signUp).subscribe(
      signUp=>{
        this.signUp=signUp;
        this.router.navigate(['/signIn']);
      },
      errorMessage=>{
        this.errorMessage='SignUp Failed'
      }
    );
      
     
    }
    
  }


