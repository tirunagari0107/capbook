import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  email:string
  emailid:string
  _oldPassword:string
  _newPassword:string
  _confirmNewPassword:string
  signUp:SignUp
  signUp1:SignUp

  get oldPassword():string{
    return this._oldPassword;
  }
  set oldPassword(value: string){
    this._oldPassword=value;
  }
  get newPassword():string{
    return this._newPassword;
  }
  set newPassword(value: string){
    this._newPassword=value;
  }
  get confirmNewPassword():string{
    return this._confirmNewPassword;
  }
  set confirmNewPassword(value: string){
    this._confirmNewPassword=value;
  }

  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
  }
  onSubmit(){
  
    this.capbookservice.changePassword(this.signUp.emailid,this._oldPassword,this._newPassword,this._confirmNewPassword).subscribe(
      signUp1=>{
          this.signUp1=signUp1;
      }
    )

  }
  public navigateBack(): void{
    this.router.navigate(['/profile'])
  }

}
