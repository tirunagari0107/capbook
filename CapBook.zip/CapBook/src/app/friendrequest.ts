export interface Friendrequest {
    senderEmail:string;
    receiverEmail:string;
    requestId:number;
}
