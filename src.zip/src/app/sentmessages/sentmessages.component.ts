import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Message } from '../message';

@Component({
  selector: 'app-sentmessages',
  templateUrl: './sentmessages.component.html',
  styleUrls: ['./sentmessages.component.css']
})
export class SentmessagesComponent implements OnInit {
  signUp:SignUp
  messageList:Message[]
  messages:Message[]
  errorMessage:string

  constructor(private route:ActivatedRoute,private router:Router,private capBookSerivce:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this.capBookSerivce.getSentMessage(this.signUp.emailid).subscribe(
      tempMessages=>{
        this.messages=tempMessages;
        this.messageList=this.messages;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )

  }

}
