import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { HttpClientModule } from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component' ;
import { RouterModule } from '@angular/router';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AppComponent } from './app.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SearchfriendsComponent } from './searchfriends/searchfriends.component';
import { SendrequestComponent } from './sendrequest/sendrequest.component';
import { ProfileComponent } from './profile/profile.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { AddfriendComponent } from './addfriend/addfriend.component';
import { RejectfriendComponent } from './rejectfriend/rejectfriend.component';
import { FriendlistComponent } from './friendlist/friendlist.component';
import { ForgotComponent } from './forgot/forgot.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { Profile2Component } from './profile2/profile2.component';




@NgModule({
  declarations: [
    
    WelcomeComponent,
    SignUpComponent,
    AppComponent,
    SignInComponent,
    SearchfriendsComponent,
    SendrequestComponent,
    ProfileComponent,
    NotificationsComponent,
    AddfriendComponent,
    RejectfriendComponent,
    FriendlistComponent,
    ForgotComponent,
    ChangepasswordComponent,
    Profile2Component
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'signUp', component: SignUpComponent  },
      { path: 'welcome', component:WelcomeComponent},
      { path: 'signIn', component:SignInComponent},
      { path: 'searchfriends', component:SearchfriendsComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full'  },
      { path: 'profile', component: ProfileComponent },
      { path: 'sendrequest', component: SendrequestComponent },
      { path: 'getNotification', component: NotificationsComponent },
      { path: 'addfriend/:senderEmail/:receiverEmail', component: AddfriendComponent },
      { path: 'rejectfriend/:senderEmail/:receiverEmail', component: RejectfriendComponent },
      { path: 'friendlist', component: FriendlistComponent },
      { path: 'forgot', component: ForgotComponent },
      { path: 'changePassword', component: ChangepasswordComponent },
      { path: 'profile2', component: Profile2Component }
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
