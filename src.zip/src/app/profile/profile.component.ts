import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Post } from '../post';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  posts:Post[]
  postsList:Post[]
  _message:string
  post:Post
  email:string
  emailid:string
  signUp:SignUp
  errorMessage:string;
  fileToUpload: File = null;
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }
  get message():string{
    return this._message;
  }
  set message(value: string){
    this._message=value;
  }
  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
   /* this.email=this.route.snapshot.paramMap.get('emailid');
    this.emailid=this.email;
    this.capbookservice.getUserDetailsByEmail(this.emailid).subscribe(
      signUp=>{
        this.signUp=this.signUp1;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );*/
    this.capbookservice.getAllPosts().subscribe(
      tempPosts=>{
        this.posts=tempPosts;
        this.postsList=this.posts;
      }
     
    );
}
onClickedPost(){
  this.capbookservice.sendPost(this._message).subscribe(
    post=>{
      this.post=post;
      this.ngOnInit();
     
    }
   
  );
  
}
handleFileInput(files: FileList) {
  this.fileToUpload = files.item(0);
  this.uploadFileToActivity();
}

uploadFileToActivity() {
console.log("in upload");
this.capbookservice.postFile(this.fileToUpload).subscribe(
 
  data => {
  console.log("success")
  },
   error => {
    console.log(error);
  });
}

}
