import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { SignUp } from '../sign-up/sign-up';
import { Post } from '../post';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
  signUp:SignUp
  posts:Post[]
  postsList:Post[]
  _message:string
  post:Post
  get message():string{
    return this._message;
  }
  set message(value: string){
    this._message=value;
  }
  constructor(private router:Router,private capbookService:CapbookserviceService) { }
  ngOnInit() {
    this.signUp = JSON.parse(sessionStorage.getItem('signUp'));
    this.capbookService.getAllPosts().subscribe(
      tempPosts=>{
        this.posts=tempPosts;
        this.postsList=this.posts;
      }
     
    );
    
  }




onClickedPost(){
    this.capbookService.sendPost(this._message).subscribe(
      post=>{
        this.post=post;
        this.router.navigate(['/timeline']);
        this.ngOnInit();
       
      }
     
    );
    
  }
}
