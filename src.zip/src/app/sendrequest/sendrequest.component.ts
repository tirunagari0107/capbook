import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Friendrequest } from '../friendrequest';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-sendrequest',
  templateUrl: './sendrequest.component.html',
  styleUrls: ['./sendrequest.component.css']
})
export class SendrequestComponent implements OnInit {
_receiverEmail:string;
_sendermail:string;
_senderEmail:string;
friendrequest:Friendrequest;
errorMessage:string;
signUp:SignUp
  get receiverEmail():string{
    return this._receiverEmail;
  }
  set receiverEmail(value: string){
    this._receiverEmail=value;
  }
  get senderEmail():string{
    return this._senderEmail;
  }
  set senderEmail(value: string){
    this._senderEmail=value;
  }
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
  }
  onSubmit(){
    this.capbookservice.sendRequest(this.signUp.emailid,this._receiverEmail).subscribe(
      friendrequest=>{
        this.friendrequest=friendrequest;
      },
     
     errorMessage=>{
      this.errorMessage = errorMessage;
    })
  
    this.router.navigate(['/sendrequest']);
     
    }
    public navigateBack(): void{
      this.router.navigate(['/profile'])
    }

}
