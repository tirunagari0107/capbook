import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Friendrequest } from '../friendrequest';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-sendrequest',
  templateUrl: './sendrequest.component.html',
  styleUrls: ['./sendrequest.component.css']
})
export class SendrequestComponent implements OnInit {

  _receiverEmail:string;
_sendermail:string;
_senderEmail:string;
friendrequest:Friendrequest;
errorMessage:string;
signUp:SignUp

  get receiverEmail():string{
    return this._receiverEmail;
  }
  set receiverEmail(value: string){
    this._receiverEmail=value;
  }
  get senderEmail():string{
    return this._senderEmail;
  }
  set senderEmail(value: string){
    this._senderEmail=value;
  }
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this._sendermail=this.route.snapshot.paramMap.get('emailid');
    this._senderEmail=this._sendermail;
    this.capbookservice.sendRequest(this.signUp.emailid,this._sendermail).subscribe(
      friendrequest=>{
        this.friendrequest=friendrequest;
      },
     
     errorMessage=>{
      this.errorMessage = 'Cannot be sent!!Either you are already friends or you are trying to send request to your own account';
    })
    this.router.navigate(['/searchfriends']);
  
  }
  onSubmit(){
    /*this._sendermail=this.route.snapshot.paramMap.get('emailid');
    this._senderEmail=this._sendermail;
    this.capbookservice.sendRequest(this.signUp.emailid,this._receiverEmail).subscribe(
      friendrequest=>{
        this.friendrequest=friendrequest;
      },
     
     errorMessage=>{
      this.errorMessage = 'Cannot be sent!!Either you are already friends or you are trying to send request to your own account';
    })
  
    this.router.navigate(['/sendrequest']);*/
     
    }

}
