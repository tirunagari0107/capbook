import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-sendmessage',
  templateUrl: './sendmessage.component.html',
  styleUrls: ['./sendmessage.component.css']
})
export class SendmessageComponent implements OnInit {
  signUp:SignUp
  _receivermail:string
  _receiverEmail:string
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this._receivermail=this.route.snapshot.paramMap.get('senderEmail');
    this._receiverEmail=this._receivermail;
  }
  onSubmit(){
    
  }

}
