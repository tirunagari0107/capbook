import { Component, OnInit } from '@angular/core';
import { CapbookserviceService } from '../services/capbookservice.service';
import { SignUp } from '../sign-up/sign-up';
import { Friendrequest } from '../friendrequest';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-searchfriends',
  templateUrl: './searchfriends.component.html',
  styleUrls: ['./searchfriends.component.css']
})
export class SearchfriendsComponent implements OnInit {
  _firstName:string=''
  error:string;
  senderEmail:string
  usersList:SignUp[];
  users:SignUp[];
  signUp:SignUp;
  friendrequest:Friendrequest;

  constructor(private capbookservice:CapbookserviceService,private route:ActivatedRoute,private router:Router) {
    this._firstName="";
  
  }


  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this.capbookservice.getAllUsers().subscribe(
      tempUsers=>{
        this.users = tempUsers;
        this.usersList = this.users;
      }
      ,
      error=>{
        this.error = error;
        
      }
    );
  }

get firstName():string{
  return this._firstName;
}
set firstName(value: string){
  this._firstName=value;
  this.usersList = this._firstName ?
      this.doProductFiltering(this._firstName):this.users
}


doProductFiltering(filterBy:string): SignUp[]{
  filterBy = filterBy.toLowerCase();
  return this.users.filter(signUp => signUp.firstName.toLowerCase().indexOf(filterBy)!==-1);
}
sendRequest1(signUp1:SignUp): Friendrequest{
  this.senderEmail=this.signUp.emailid;
  this.capbookservice.sendRequest(this.senderEmail,signUp1.emailid).subscribe(
    friendrequest=>{
      this.friendrequest=friendrequest;
      this.ngOnInit();
      this.router.navigate(['/searchfriends']);
    },
  
    
  );
  return this.friendrequest;
}

}
