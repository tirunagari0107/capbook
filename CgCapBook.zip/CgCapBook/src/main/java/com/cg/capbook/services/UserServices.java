package com.cg.capbook.services;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.FriendsList;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.EmptyFriendListException;
import com.cg.capbook.exceptions.FriendRequestException;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.UserNotFoundException;
public interface UserServices {
	User acceptUserDetails(User user) throws NoSuchAlgorithmException;
	User getUserDetails(String emailId,String password) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException;
	public ArrayList<User> getAllUsers();
	FriendRequest sendFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException, FriendRequestException;
	FriendRequest acceptFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException, FriendRequestException;
	List<FriendsList> getUserFriendList(String emailId) throws UserNotFoundException, EmptyFriendListException;
	FriendRequest deleteFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException,FriendRequestException;
	User changePassword(String emailId,String oldPassword,String newPassword,String confirmNewPassword) throws UserNotFoundException, IncorrectPasswordException;
	User forgotPassword(String emailId,String securityQuestion,String securityAnswer,String newPassword) throws UserNotFoundException, IncorrectPasswordException;
	List<FriendRequest> getNotifications(String emailid) throws UserNotFoundException ;
	User getUserDetailsByEmail(String emailid) throws UserNotFoundException;
	 ArrayList<String> getAllFriendRequestSent(String receiverEmail) throws UserNotFoundException, EmptyFriendListException;
	 ArrayList<String> getAllFriendRequestReceived(String senderEmail)
				throws UserNotFoundException, EmptyFriendListException;
	 void uploadProfilePicture(CommonsMultipartFile image, String emailId) throws UserNotFoundException;
	 byte[] getProfilePicture(String emailId) throws UserNotFoundException ;


}