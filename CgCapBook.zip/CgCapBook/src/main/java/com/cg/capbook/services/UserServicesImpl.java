package com.cg.capbook.services;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.FriendsList;
import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.UploadFile;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.FriendListDAO;
import com.cg.capbook.daoservices.FriendRequestDAO;
import com.cg.capbook.daoservices.MessageDAO;
import com.cg.capbook.daoservices.PostDAO;
import com.cg.capbook.daoservices.UploadFileDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.EmptyFriendListException;
import com.cg.capbook.exceptions.FriendRequestException;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.PostNotFoundException;
import com.cg.capbook.exceptions.UserNotFoundException;
import com.cg.capbook.util.SortByDateAsc;
@Component
public class UserServicesImpl implements UserServices{
	
	public static String sessionEmailId=null;
	@Autowired
	UserDAO userDAO;
	@Autowired
	FriendRequestDAO friendRequestDAO;
	@Autowired
	FriendListDAO friendListDAO;
	@Autowired
	UploadFileDAO uploadFileDAO;
	@Autowired
	PostDAO postDAO;
	@Autowired
	MessageDAO messageDAO;
	
	private String passwordHashing(String actualPassword) throws NoSuchAlgorithmException {
		MessageDigest hashingMethod= MessageDigest.getInstance("MD5");
		byte[] messageDigest = hashingMethod.digest(actualPassword.getBytes());
		BigInteger signum = new BigInteger(1, messageDigest);
		String hashPassword = signum.toString(16);
		while(hashPassword.length()<32) {
			hashPassword = "0" + hashPassword;
		}
		return hashPassword;
	}
	@Override
	public User acceptUserDetails(User user) throws NoSuchAlgorithmException {
		user.setPassword(passwordHashing(user.getPassword()));
		user.setConfirmPassword(user.getPassword());
		user=userDAO.save(user);
		return user;
	}
	@Override
	public User getUserDetails(String emailId,String password) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException {
		User user=userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException("User Details Not found"));
		password = passwordHashing(password);
		if(!user.getPassword().equals(password)) throw new IncorrectPasswordException("Incorrect Password");
		sessionEmailId=user.getEmailid();
		return user;
	}
	@Override
	public ArrayList<User> getAllUsers() {
		return (ArrayList<User>) userDAO.findAll();
	}
	@Override
	public FriendRequest sendFriendRequest(String senderEmail, String receiverEmail) throws UserNotFoundException, FriendRequestException {
		User sender=userDAO.findById(senderEmail).orElseThrow(()->new UserNotFoundException("User Details Not found"));
		userDAO.findById(receiverEmail).orElseThrow(()->new UserNotFoundException("User Details Not found"));
		if(senderEmail.equals(receiverEmail)) throw new FriendRequestException("Cannot send to your own account");
		FriendsList friendsList=friendListDAO.checkFriendList(senderEmail,receiverEmail);
		if(friendsList!=null)throw new FriendRequestException("Already friends"); 
		/*if(sender.getFriendList()!=null){
			for(String email:sender.getFriendList())
				if(receiverEmail.equals(email)) throw new FriendRequestException("Already friends");}*/
		FriendRequest request1=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		FriendRequest request2=friendRequestDAO.getFriendRequestId(receiverEmail,senderEmail);
		if(request1!=null) throw new FriendRequestException("Request already sent");
		if(request2!=null) throw new FriendRequestException("Request pending from sender");
		FriendRequest friendRequest=new FriendRequest(senderEmail,receiverEmail);
		friendRequestDAO.save(friendRequest);
		return friendRequest;
	}
	@Override
	public FriendRequest acceptFriendRequest(String senderEmail, String receiverEmail) throws UserNotFoundException, FriendRequestException {
		User sender=userDAO.findById(senderEmail).orElseThrow(()->new UserNotFoundException("Sender Details Not found"));
		User receiver=userDAO.findById(receiverEmail).orElseThrow(()->new UserNotFoundException("Receiver Details Not found"));
		FriendRequest request=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		if(request==null) throw new FriendRequestException("Request not found exception");	
		
		/*if(sender.getFriendList()==null) 
			sender.setFriendList(new ArrayList<>());
		if(receiver.getFriendList()==null) 
			receiver.setFriendList(new ArrayList<>());
		sender.getFriendList().add(receiverEmail);*/
		String fullName1=sender.getFullName();
		FriendsList friendsList=new FriendsList(senderEmail, fullName1, receiverEmail);
		friendListDAO.save(friendsList);	
		/*receiver.getFriendList().add(senderEmail);*/
		String fullName2=receiver.getFullName();
		FriendsList friendsList2=new FriendsList(receiverEmail,fullName2, senderEmail);
		friendListDAO.save(friendsList2);
		/*userDAO.save(sender);
		userDAO.save(receiver);*/
		friendRequestDAO.delete(request);
		return request;
	}
	@Override
	public List<FriendsList> getUserFriendList(String emailId) throws UserNotFoundException, EmptyFriendListException {
		User user= userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException());
		List<FriendsList> friendsList=friendListDAO.getFriendList(emailId);
		return friendsList;
	}
	@Override
	public FriendRequest deleteFriendRequest(String senderEmail, String receiverEmail)
			throws UserNotFoundException, FriendRequestException {
		userDAO.findById(senderEmail).orElseThrow(()->new UserNotFoundException("Sender Details Not found"));
		userDAO.findById(receiverEmail).orElseThrow(()->new UserNotFoundException("Receiver Details Not found"));
		FriendRequest request=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		if(request==null) throw new FriendRequestException("No Requests Found");
		 friendRequestDAO.deleteById(request.getRequestId());
		 return  request;                                                                                                                                                                                                                                                                                                                                                                                                                                    
	}
	@Override
	public User changePassword(String emailId,String oldPassword, String newPassword, String confirmNewPassword) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException {
		User user=userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException("User not found"));
		System.out.println(user.getPassword());
		String old=passwordHashing(oldPassword);
		if(!passwordHashing(oldPassword).equals(user.getPassword())) throw new IncorrectPasswordException("Incorrect Password");
		if(oldPassword.equals(newPassword)) throw new IncorrectPasswordException("Please Enter password that is different from old password");
		if(newPassword.equals(confirmNewPassword)) {
			user.setPassword(passwordHashing(newPassword));
		User user1=userDAO.save(user);
		return user1;}
		else throw new IncorrectPasswordException("Password Mismatch");
	}
	@Override
	public User forgotPassword(String emailId, String securityQuestion, String securityAnswer, String newPassword) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException {
	User user=userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException("User not found"))	;
	if(user.getSecurityQuestion().equals(securityQuestion) && user.getSecurityAnswer().equals(securityAnswer)) {
		user.setPassword(passwordHashing(newPassword));
		User user1=userDAO.save(user);
		return user1;}
	else throw new IncorrectPasswordException("Incorrect Question or Answer");
	
	}	
	@Override
	public List<FriendRequest> getNotifications(String emailid) throws UserNotFoundException {
		User user=userDAO.findById(emailid).orElseThrow(()->new UserNotFoundException());
		List<FriendRequest> request=friendRequestDAO.getNotifications(emailid);
		return request;
	}
	@Override
	public User getUserDetailsByEmail(String emailId) throws UserNotFoundException {
		User user=userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException());
		return user;
	}	
	@Override
	public ArrayList<FriendRequest> getAllFriendRequestSent(String receiverEmail) throws UserNotFoundException, EmptyFriendListException {
		User user=userDAO.findById(receiverEmail).orElseThrow(()->new UserNotFoundException("User not found"))	;
		ArrayList<FriendRequest> friendList = friendRequestDAO.getAllFriendRequestSent(receiverEmail);
		return friendList;

	}
	@Override
	public ArrayList<FriendRequest> getAllFriendRequestReceived(String senderEmail)
			throws UserNotFoundException, EmptyFriendListException {
		User user=userDAO.findById(senderEmail).orElseThrow(()->new UserNotFoundException("User not found"))	;
		ArrayList<FriendRequest> friendList = friendRequestDAO.getAllFriendRequestReceived(senderEmail);
		return friendList;
	}
	
	@Override
	public User insertProfilePic(byte[] profilePic) {
		System.out.println(sessionEmailId);
		User profile=userDAO.findById(sessionEmailId).get();
		profile.setProfilePic(profilePic);
		return userDAO.save(profile);
	}
	@Override
	public byte[] fetchProfilePic() {
		User user=userDAO.findById(sessionEmailId).get();
		return user.getProfilePic();
	}
	
	
	@Override
	public Message sendMessage(String senderEmail, String receiverEmail, String textMessage) throws UserNotFoundException {
		User sender=userDAO.findById(senderEmail).orElseThrow(() -> new UserNotFoundException("User not found"));
		User receiver=userDAO.findById(receiverEmail).orElseThrow(() -> new UserNotFoundException("User not found"));
		Message message=new Message(textMessage, sender.getFullName(), receiver.getFullName(), senderEmail, receiverEmail);
		return messageDAO.save(message);
	}
	@Override
	public ArrayList<Message> getSentMessage(String senderEmail) throws UserNotFoundException {
		User sender=userDAO.findById(senderEmail).orElseThrow(() -> new UserNotFoundException("User not found"));
		ArrayList<Message> messages=messageDAO.getSentMessage(senderEmail);
		return messages;
	}
	@Override
	public ArrayList<Message> getReceivedMessage(String receiverEmail)throws UserNotFoundException  {
		User sender=userDAO.findById(receiverEmail).orElseThrow(() -> new UserNotFoundException("User not found"));
		ArrayList<Message> messages=messageDAO.getReceivedMessage(receiverEmail);
		return messages;
	}
	@Override
	public List<User> findFriends(String emailId) throws UserNotFoundException, EmptyFriendListException {
		User person = getUserDetailsByEmail(emailId);
		List<User> friends= userDAO.findNewFriends(emailId);
	     List<FriendsList> friendsList=getUserFriendList(emailId);
	     for (FriendsList friendList : friendsList) {
	    	 friends.remove(userDAO.findById(friendList.getSenderEmail()).get());
	    	 friends.remove(userDAO.findById(friendList.getReceiverEmail()).get());
		}
	     List<FriendRequest> friendsRequest=getAllFriendRequestSent(emailId);
		 for (FriendRequest friendList : friendsRequest) {
	    	 friends.remove(userDAO.findById(friendList.getSenderEmail()).get());
	    	 friends.remove(userDAO.findById(friendList.getReceiverEmail()).get());
		}
		 List<FriendRequest> friendsRequests=getAllFriendRequestReceived(emailId);
		 for (FriendRequest friendList : friendsRequests) {
	    	 friends.remove(userDAO.findById(friendList.getSenderEmail()).get());
	    	 friends.remove(userDAO.findById(friendList.getReceiverEmail()).get());
		}
		return friends;
	}
	@Override
	public User updateProfile(User user) {
		User user1=userDAO.findById(user.getEmailid()).get();
		user1.setCity(user.getCity());
		System.out.println(user.getCity());
		user1.setCollegeName(user.getCollegeName());
		user1.setCountry(user.getCountry());
		user1.setRelationShipStatus(user.getRelationShipStatus());
		user1.setState(user.getState());
		userDAO.save(user1);
		return user1;
	}
	@Override
	public Post sendPost( String message) throws UserNotFoundException, EmptyFriendListException {
		User user=userDAO.findById(sessionEmailId).orElseThrow(()->new UserNotFoundException("Sorry User Not Found!!!")); 
		Post post =new Post(user, message,  new Date());
		postDAO.save(post);	
		return post;
	}

	@Override
	public List<Post> getAllPosts() throws UserNotFoundException, EmptyFriendListException {
		List<Post> posts=new ArrayList<Post>();
		posts.addAll(myPosts(sessionEmailId));
		List<FriendsList>friendList =getUserFriendList(sessionEmailId);
		/*List<User> users = userDAO.findAll();
		for (FriendsList friends : friendList) {
			for(User user:users) {
			if(user.getFullName()!=friends.getFullName()|| user.getEmailid()==friends.getSenderEmail())
				users.remove(user);
			users.removeAll(findFriends(sessionEmailId));
		}}	*/
		for (FriendsList friend: friendList) 
			posts.addAll(myPosts(friend.getSenderEmail()));	
		Collections.sort(posts);
		return posts;
	}	
	@Override
	public List<Post> myPosts(String emailId) throws UserNotFoundException {
		User user=userDAO.findById(emailId).orElseThrow(()->new UserNotFoundException("Sorry User Not Found!!!")); 
		List<Post> myPosts= postDAO.getMyPosts(user);
		Collections.sort(myPosts);
		return myPosts;
	}	
}